# Imagen 4 Ultra Prompts - Optimized for Google AI Studio
## Dual-Theme Portfolio Images (36 total)

**Model:** Imagen 4 Ultra
**Aspect Ratio:** 3:2 (select in UI dropdown)
**Total Cost:** ~$2.16 (36 images × $0.06)
**Date:** November 17, 2025

---

## OPTIMIZATION FOR IMAGEN 4 ULTRA

Imagen 4 Ultra excels at:
- Nuanced, conceptual prompts (better than literal descriptions)
- Emotional tone and mood
- Photorealistic quality with intricate details
- Minimal post-processing needed

**Prompt Structure:**
1. Lead with emotional/conceptual tone
2. Describe composition and visual hierarchy
3. Specify colors with hex codes
4. Add technical elements and logos
5. End with style/aesthetic direction

---

## PROJECT THUMBNAILS (4 projects × 2 = 8 images)

### 1. RAG Knowledge System

#### Light Mode
**File:** `/assets/img/projects/rag-thumbnail-light.png`
**Aspect Ratio:** 3:2 landscape

```
Professional technical visualization conveying intelligent data flow and semantic understanding. Clean white background (#FFFFFF) with subtle gradient. Central luminous vector database represented as crystalline cube in vibrant blue, radiating organized energy. Left side: document icons in professional grey transforming into flowing data streams. Right side: AI neural network visualization in purple-blue gradient responding with insights. Bottom: Pinecone, ChromaDB, Weaviate, GPT-4, Claude, LangChain technology logos integrated naturally. "RAG System for Enterprise Knowledge" title in Inter font, dark charcoal text (#1c1c1d). Strategic ember orange accents (#D95B43) highlighting key transformation points. Modern, sophisticated tech aesthetic with emphasis on clarity and precision. Dense composition filling frame edge-to-edge.
```

#### Dark Mode
**File:** `/assets/img/projects/rag-thumbnail-dark.png`
**Aspect Ratio:** 3:2 landscape

```
Professional technical visualization with futuristic energy, conveying intelligent data flow in darkness. Deep charcoal background (#1c1c1d) creating dramatic contrast. Central glowing vector database as luminescent crystalline cube in electric blue with subtle radiance. Documents transforming into flowing streams of light particles. AI neural network responding with brilliant purple-blue neural pathways. Technology logos (Pinecone, ChromaDB, Weaviate, GPT-4, Claude, LangChain) with subtle glow effects. "RAG System for Enterprise Knowledge" in Inter font, crisp white text. Ember orange highlights (#D95B43) with warm luminescence on critical connection points. Sophisticated neon-tech aesthetic balancing drama with professionalism. Dense composition, no empty space.
```

---

### 2. Cloud MLOps Platform

#### Light Mode
**File:** `/assets/img/projects/cloud-thumbnail-light.png`
**Aspect Ratio:** 3:2 landscape

```
Enterprise DevOps architecture visualization radiating scalability and automation confidence. Clean white canvas. Central Kubernetes cluster in official blue (#326CE5) with three pod icons suggesting orchestrated movement. Docker container on left in signature blue, cloud infrastructure on right in soft azure tones. Redis cache icon (red #DC382D) and FastAPI logo (teal) positioned strategically. Upward-trending autoscaling arrow in professional grey showing growth trajectory. Technology stack: Kubernetes, Docker, FastAPI, Redis, Istio logos naturally integrated. "Cloud MLOps Platform" title in Inter font, dark text (#1c1c1d). Blue-teal gradient flows with ember orange (#D95B43) accents on scaling components. Clean architectural diagram style, production-grade professionalism. Fill frame completely.
```

#### Dark Mode
**File:** `/assets/img/projects/cloud-thumbnail-dark.png`
**Aspect Ratio:** 3:2 landscape

```
Enterprise DevOps architecture with electric sophistication, radiating automated scalability. Dark charcoal background (#1c1c1d). Glowing Kubernetes cluster in brilliant blue (#326CE5) with luminous pod icons. Docker container with subtle blue radiance, cloud infrastructure glowing in bright azure. Redis cache and FastAPI logos with vibrant highlights. Upward autoscaling arrow with dynamic energy suggesting continuous growth. Technology logos (Kubernetes, Docker, FastAPI, Redis, Istio) with professional glow effects. "Cloud MLOps Platform" in Inter font, white text. Electric blue-teal gradients with bright ember orange (#D95B43) accents creating energy on autoscaling elements. Modern glowing infrastructure aesthetic. Dense, edge-to-edge composition.
```

---

### 3. NLP Sentiment Analysis

#### Light Mode
**File:** `/assets/img/projects/nlp-thumbnail-light.png`
**Aspect Ratio:** 3:2 landscape

```
Data science pipeline visualization expressing analytical precision and intelligence. White background (#FFFFFF). Left-to-right transformation flow: text document icon in grey → sophisticated neural network (FinBERT architecture) with layered blue-purple gradient suggesting deep learning → sentiment analysis outputs with green (positive), red (negative), grey (neutral) indicator icons. Prominent accuracy gauge displaying "80.6%" in bold dark text with ember orange accent (#D95B43) suggesting achievement. Bottom: Python, PyTorch, FinBERT, Optuna technology logos. "NLP Sentiment Engine" title in Inter font, charcoal text (#1c1c1d). Clean analytical aesthetic balancing technical depth with accessibility. Compact layout maximizing information density.
```

#### Dark Mode
**File:** `/assets/img/projects/nlp-thumbnail-dark.png`
**Aspect Ratio:** 3:2 landscape

```
Data science pipeline with intelligent luminescence, expressing analytical mastery. Dark background (#1c1c1d). Text document transforming through glowing FinBERT neural network with electric blue-purple layers radiating processing energy. Sentiment indicators: bright green (positive glow), vivid red (negative energy), light grey (neutral) with subtle radiance. Accuracy gauge "80.6%" in prominent white text with glowing ember orange accent (#D95B43) celebrating performance. Technology logos (Python, PyTorch, FinBERT, Optuna) with professional illumination. "NLP Sentiment Engine" title in Inter font, white. Electric analytical aesthetic with neon gradients suggesting AI intelligence. Dense, space-efficient composition.
```

---

### 4. Computer Vision Medical Imaging

#### Light Mode
**File:** `/assets/img/projects/cv-thumbnail-light.png`
**Aspect Ratio:** 3:2 landscape

```
Medical AI visualization conveying diagnostic precision and clinical trust. Clean white background. Central chest X-ray silhouette in medical blue-grey with heat map overlay highlighting disease regions in diagnostic red-orange gradients. "96+ AUC" metric prominently displayed in dark text with ember accent (#D95B43) signifying clinical excellence. CNN neural network architecture surrounding X-ray in structured blue-purple layers suggesting deep analysis. Technology logos: TensorFlow, OpenCV, scikit-image integrated professionally. "Medical Imaging AI" title in Inter font, dark charcoal (#1c1c1d). Clinical blue-red color scheme balancing medical authority with AI innovation. Professional healthcare aesthetic prioritizing trustworthiness.
```

#### Dark Mode
**File:** `/assets/img/projects/cv-thumbnail-dark.png`
**Aspect Ratio:** 3:2 landscape

```
Medical AI visualization with sophisticated radiance, expressing diagnostic intelligence. Dark background (#1c1c1d). Luminous chest X-ray with glowing heat map revealing pathology regions in bright red-orange with clinical precision. "96+ AUC" metric in white text with brilliant ember glow (#D95B43) celebrating accuracy. Glowing CNN neural network in electric blue-purple surrounding X-ray with pulsing energy suggesting active analysis. Technology logos (TensorFlow, OpenCV, scikit-image) with professional illumination. "Medical Imaging AI" in Inter font, white text. Medical blues and diagnostic reds with neon clarity. Advanced healthcare technology aesthetic. Dense composition.
```

---

## PROFESSIONAL CASE STUDY THUMBNAILS (7 × 2 = 14 images)

### 1. Time Tracking & Resource Allocation

#### Light Mode
**File:** `/assets/img/casestudies/time-tracking-light.png`
**Aspect Ratio:** 3:2 landscape

```
Corporate transformation story expressing company-wide adoption and executive validation. White background. Central clock/calendar icon in professional blue emanating connection rays to circular arrangement of employee profile icons representing organizational reach. Upward progression arrow from small application to enterprise platform showing growth journey. "Company-Wide" badge with executive approval checkmark in ember orange (#D95B43) signifying leadership endorsement. Subtle Google brand colors accent. Blue-purple gradient suggesting innovation. "Time Tracking & Resource Allocation" in Inter font, dark text. Clean corporate aesthetic emphasizing scale, trust, and executive visibility. Compact, purposeful layout.
```

#### Dark Mode
**File:** `/assets/img/casestudies/time-tracking-dark.png`
**Aspect Ratio:** 3:2 landscape

```
Corporate transformation with modern luminescence, expressing organizational empowerment. Dark background (#1c1c1d). Glowing clock/calendar with radiant connection beams to employee icons creating network effect. Upward progression arrow with dynamic energy showing application evolution. Glowing "Company-Wide" badge with executive checkmark in bright ember orange (#D95B43) signaling top-level approval. Google brand colors with neon vitality. Electric blue-purple gradients. "Time Tracking & Resource Allocation" in Inter font, white text. Modern corporate aesthetic with sophisticated glow. Dense composition conveying enterprise reach.
```

---

### 2. Strategic Connective Tissue (4.5x Growth)

#### Light Mode
**File:** `/assets/img/casestudies/connective-tissue-light.png`
**Aspect Ratio:** 3:2 landscape

```
Organizational architecture expressing cross-functional harmony and exponential growth. White background. Hub-and-spoke design: central star node in ember orange (#D95B43) representing strategic connector, four spokes extending to quadrants labeled "Leadership" (blue), "Finance" (green), "Product" (orange), "IT" (purple). Each quadrant contains employee icons in professional grey. Growth metric "50 → 225+" prominently displayed showing 4.5x expansion. Connecting bridges between quadrants through central hub emphasizing integration. "Strategic Connective Tissue" in Inter font, charcoal text. Professional org chart aesthetic celebrating connection over hierarchy. Balanced, symmetrical composition.
```

#### Dark Mode
**File:** `/assets/img/casestudies/connective-tissue-dark.png`
**Aspect Ratio:** 3:2 landscape

```
Organizational architecture with electric vitality, expressing unified growth through connection. Dark background (#1c1c1d). Glowing central star in brilliant ember orange (#D95B43) radiating energy to four illuminated quadrants: "Leadership" (electric blue), "Finance" (bright green), "Product" (vivid orange), "IT" (bright purple). Employee icons with subtle glow. Growth metric "50 → 225+" in white text with radiance showing exponential impact. Luminous connection bridges. "Strategic Connective Tissue" in Inter font, white. Modern org structure with neon clarity emphasizing integration. Symmetrical glowing composition.
```

---

### 3. The $100M+ Inventory Project

#### Light Mode
**File:** `/assets/img/casestudies/inventory-100m-light.png`
**Aspect Ratio:** 3:2 landscape

```
Finance operations transformation expressing analytical rigor leading to massive ROI. White background. Horizontal four-stage journey with connecting timeline: "1. Analysis" (magnifying glass, blue) → "2. Root Cause" (gear mechanism, purple) → "3. Business Case" (financial chart, green) → "4. AI Solution" (robot intelligence, orange). Center: dominant "$100M+" in ember orange (#D95B43) expressing extraordinary financial impact. Subtle warehouse/inventory visual context with grey package icons. ML badge and "Single Quarter" timeframe emphasizing speed of value delivery. Python, scikit-learn logos. "The $100M+ Inventory Project" in Inter font, dark text. Professional finance aesthetic prioritizing ROI clarity.
```

#### Dark Mode
**File:** `/assets/img/casestudies/inventory-100m-dark.png`
**Aspect Ratio:** 3:2 landscape

```
Finance operations transformation with dramatic radiance, expressing AI-driven value creation. Dark background (#1c1c1d). Glowing four-stage timeline: luminous magnifying glass (blue) → glowing gear (purple) → bright chart (green) → radiant robot (orange). Center: massive glowing "$100M+" in brilliant ember orange (#D95B43) dominating composition with financial significance. Warehouse context with subtle grey packages. Glowing ML badge and "Single Quarter" indicator. Python, scikit-learn logos with illumination. "The $100M+ Inventory Project" in Inter font, white text. Dramatic finance aesthetic with neon emphasis on ROI. Dense composition.
```

---

### 4. The Revenue Platform (0→8,000 Users)

#### Light Mode
**File:** `/assets/img/casestudies/revenue-platform-light.png`
**Aspect Ratio:** 3:2 landscape

```
Business transformation narrative expressing dramatic turnaround and explosive adoption. White background. Split composition showing before/after: LEFT in warning red tones - "0 Users" with broken disconnected icon suggesting failure. RIGHT in success green tones - "8,000 Users" with connected network icon and upward arrow "+32% Y/Y" showing growth momentum. Center: bold transformation arrow in ember orange (#D95B43) signifying turning point. "Single Source of Truth" badge with database icon emphasizing data integrity. Subtle upward trending graphs. "Revenue Platform Transformation" in Inter font, dark text. Business intelligence aesthetic emphasizing dramatic positive change. Balanced split composition.
```

#### Dark Mode
**File:** `/assets/img/casestudies/revenue-platform-dark.png`
**Aspect Ratio:** 3:2 landscape

```
Business transformation with electric drama, expressing platform resurrection and massive adoption. Dark background (#1c1c1d). Split composition: LEFT in bright warning red - "0 Users" with broken icon. RIGHT in vibrant success green - "8,000 Users" with glowing connected network and upward growth arrow "+32% Y/Y". Center: brilliant transformation arrow in glowing ember orange (#D95B43). Luminous "Single Source of Truth" badge with database icon. Glowing upward trending graphs suggesting business momentum. "Revenue Platform Transformation" in Inter font, white text. Dramatic BI aesthetic with neon clarity. Balanced split conveying turnaround story.
```

---

### 5. SAP Transition & Finance Modernization

#### Light Mode
**File:** `/assets/img/casestudies/sap-transition-light.png`
**Aspect Ratio:** 3:2 landscape

```
Enterprise modernization journey expressing seamless evolution without disruption. White background. Three-stage transformation: LEFT - legacy system (filing cabinet, paper documents, dated computer in grey/sepia tones suggesting old technology). CENTER - migration bridge with "Zero Downtime" badge in ember orange (#D95B43) emphasizing continuity. RIGHT - modern SAP (cloud icon in blue, automation gears in purple, streamlined workflows showing efficiency). "100% Uptime" indicator throughout showing reliability. Contrast "Manual Legacy" versus "Automated Modern". SAP branding reference. "SAP Transition & Modernization" in Inter font, dark text. Enterprise transformation aesthetic prioritizing trust and continuity.
```

#### Dark Mode
**File:** `/assets/img/casestudies/sap-transition-dark.png`
**Aspect Ratio:** 3:2 landscape

```
Enterprise modernization with sophisticated radiance, expressing seamless technological evolution. Dark background (#1c1c1d). Three stages: LEFT - dim legacy system (filing cabinet, paper, old computer fading into darkness). CENTER - glowing migration bridge with brilliant "Zero Downtime" badge in ember orange (#D95B43). RIGHT - luminous modern SAP (bright cloud, glowing automation gears, streamlined workflows radiating efficiency). "100% Uptime" indicator with glow. Contrast dim legacy versus bright modern. SAP branding. "SAP Transition & Modernization" in Inter font, white text. Enterprise aesthetic with dramatic before/after lighting emphasizing transformation.
```

---

### 6. Cost & Profitability Framework (>100K SKUs)

#### Light Mode
**File:** `/assets/img/casestudies/profitability-framework-light.png`
**Aspect Ratio:** 3:2 landscape

```
Financial analytics visualization expressing granular P&L intelligence at massive scale. White background. Vertical P&L waterfall flowing downward with structured blue bars: "List Price" → "Net Revenue" → "Gross Margin" → "Operating Margin" with connecting waterfall lines showing margin flow. Right side: magnifying glass focusing on ">100K SKUs" text with product grid pattern suggesting massive granularity. Layered depth visualization showing attribution across multiple dimensions. "Full P&L Stack" label with layered icon. "Millions Identified" optimization metric in ember orange (#D95B43). "Profitability Framework" in Inter font, dark text. Professional financial analytics aesthetic emphasizing precision at scale.
```

#### Dark Mode
**File:** `/assets/img/casestudies/profitability-framework-dark.png`
**Aspect Ratio:** 3:2 landscape

```
Financial analytics with luminous precision, expressing intelligent P&L mastery at scale. Dark background (#1c1c1d). Glowing P&L waterfall with blue-green gradient bars flowing downward showing margin progression. Luminous magnifying glass revealing ">100K SKUs" with glowing product grid. Layered depth visualization with radiant attribution layers. Glowing "Full P&L Stack" label. "Millions Identified" in brilliant ember orange (#D95B43) celebrating financial optimization. "Profitability Framework" in Inter font, white text. Financial intelligence aesthetic with electric clarity emphasizing analytical depth. Dense composition.
```

---

### 7. AI-Powered Analytics Assistant

#### Light Mode
**File:** `/assets/img/casestudies/ai-analytics-assistant-light.png`
**Aspect Ratio:** 3:2 landscape

```
AI business intelligence expressing democratized data access through natural language. White background. Center: conversational interface showing user question "What drove Q3 revenue growth?" with AI response containing insights, charts, and data visualizations in blue-purple tones. Three capability icons: "Revenue Data" (bar chart, blue), "Methodologies" (document, grey), "Code" (terminal brackets, purple) showing versatile intelligence. Gemini AI badge with RAG architecture indicator. Right: user silhouettes representing "8,000+ Users" showing enterprise adoption. Subtle financial dashboard overlays. "AI Analytics Assistant" in Inter font, dark text. Business intelligence aesthetic emphasizing accessibility and natural interaction. Information-dense composition.
```

#### Dark Mode
**File:** `/assets/img/casestudies/ai-analytics-assistant-dark.png`
**Aspect Ratio:** 3:2 landscape

```
AI business intelligence with electric sophistication, expressing conversational data mastery. Dark background (#1c1c1d). Glowing conversation interface: user query "What drove Q3 revenue growth?" with luminous AI response showing insights, charts, visualizations in electric blue-purple. Three glowing capability icons: "Revenue Data" (bright bar chart), "Methodologies" (glowing document), "Code" (luminous terminal). Gemini AI badge and RAG indicator with radiance. Glowing user silhouettes showing "8,000+ Users" adoption scale. Luminous financial dashboards overlay. "AI Analytics Assistant" in Inter font, white text. Modern BI aesthetic with neon clarity emphasizing AI intelligence. Dense composition.
```

---

## MIDS CASE STUDY THUMBNAILS (4 × 2 = 8 images)

### 1. RAG Knowledge - 95% Adoption

#### Light Mode
**File:** `/assets/img/casestudies/rag-knowledge-light.png`
**Aspect Ratio:** 3:2 landscape

```
Knowledge transformation narrative expressing technical precision leading to business adoption. White background. Split composition: LEFT - chaotic scattered knowledge silos (email icons, SharePoint folders, desktop files in disorganized grey) with frustrated employee silhouettes suggesting pain. RIGHT - unified knowledge graph with organized blue hub, happy employees at workstations with instant answer bubbles showing relief. CENTER: transformation arrow with technical callout "256-token chunks, k=8 retrieval" in dark text emphasizing architecture choice. Top metrics in clean boxes: "95% Adoption", "60% Time Saved", "+15% Win Rate" with ember orange accents (#D95B43). Bottom: engineer vs marketer persona icons with tailored responses. "Why 256-Token Chunks Beat Your LLM Choice" in Inter font, dark text. Professional services aesthetic balancing technical depth with business impact.
```

#### Dark Mode
**File:** `/assets/img/casestudies/rag-knowledge-dark.png`
**Aspect Ratio:** 3:2 landscape

```
Knowledge transformation with dramatic radiance, expressing architectural precision driving adoption. Dark background (#1c1c1d). Split: LEFT - chaotic silos in dim red-orange warning tones with frustrated silhouettes. RIGHT - glowing unified knowledge graph with electric blue hub radiating light, happy employees with luminous instant answers. CENTER: brilliant transformation arrow with "256-token chunks, k=8 retrieval" callout glowing. Top: glowing metrics "95% Adoption", "60% Time Saved", "+15% Win Rate" in bright ember orange (#D95B43). Glowing persona icons with tailored responses. "Why 256-Token Chunks Beat Your LLM Choice" in Inter font, white text. Dramatic professional services aesthetic emphasizing technical choices driving business results.
```

---

### 2. CV Medical Imaging - 96+ AUC

#### Light Mode
**File:** `/assets/img/casestudies/cv-medical-light.png`
**Aspect Ratio:** 3:2 landscape

```
Medical AI expressing feature engineering triumph over deep learning complexity. White background. Center: chest X-ray in medical blue-grey with highlighted pathology regions (Cardiomegaly, Pleural Effusion, Pneumothorax) in diagnostic red-orange overlays. LEFT panel: feature engineering visualization - cardiac-thoracic ratio measurement lines in blue, lung field symmetry indicators showing human-designed intelligence. RIGHT panel: model comparison showing Logistic Regression "F1: 0.801" in success green beating CNN "F1: 0.401" in grey. Top: arc of 14 disease class labels. Metrics: "96+ AUC", "80% Accuracy", "F1: 0.801 vs 0.401" with ember accents (#D95B43). ROC curves. "Medical Imaging AI for Chest X-Ray Diagnosis" in Inter font, dark text. Clinical precision aesthetic celebrating interpretable AI.
```

#### Dark Mode
**File:** `/assets/img/casestudies/cv-medical-dark.png`
**Aspect Ratio:** 3:2 landscape

```
Medical AI with luminous clarity, expressing feature engineering mastery. Dark background (#1c1c1d). Center: glowing chest X-ray with bright pathology highlights (Cardiomegaly, Pleural Effusion, Pneumothorax) in vivid red-orange radiance. LEFT: glowing feature engineering - cardiac-thoracic ratio lines in electric blue, lung symmetry indicators. RIGHT: glowing comparison - Logistic Regression "F1: 0.801" in bright green triumph over dim CNN "F1: 0.401". Top: glowing 14 disease labels in arc. Bright metrics: "96+ AUC", "80% Accuracy", comparison in brilliant ember orange (#D95B43). Glowing ROC curves. "Medical Imaging AI for Chest X-Ray Diagnosis" in Inter font, white text. Clinical aesthetic with neon precision celebrating smart features over complexity.
```

---

### 3. NLP Feedback - 80.6% Accuracy

#### Light Mode
**File:** `/assets/img/casestudies/nlp-feedback-light.png`
**Aspect Ratio:** 3:2 landscape

```
Customer intelligence transformation expressing ensemble learning capturing business value. White background. Center: massive customer feedback streams from 8 sources (Zendesk grey tickets, Twitter blue posts, App Store green reviews, NPS purple surveys, sales orange calls) converging into NLP processing engine with blue-purple neural network. Engine: 3 transformer models (FinBERT, DistilBERT, RoBERTa) with "2-of-3 consensus voting" label. Output: clean dashboard - sentiment trends (green positive, red negative), category tags, red churn risk alerts. Confusion matrix showing "50% reduction in negative misclassification". Bold metrics: "150K+ Items/Year", "12% Churn Reduction", "2.3x Feature Adoption", "80.6% Accuracy" in ember orange (#D95B43). "When Machine-Generated Labels Outperform Human Annotation" in Inter font, dark text. SaaS product aesthetic emphasizing noise-to-intelligence transformation.
```

#### Dark Mode
**File:** `/assets/img/casestudies/nlp-feedback-dark.png`
**Aspect Ratio:** 3:2 landscape

```
Customer intelligence with electric energy, expressing AI ensemble mastering feedback chaos. Dark background (#1c1c1d). Glowing multicolor feedback streams from 8 sources converging into luminous NLP engine with electric blue-purple neural network radiating processing power. Glowing 3 transformer ensemble with bright "2-of-3 consensus" voting. Output: glowing dashboard - bright green positive sentiment, vivid red negative, glowing category tags, bright churn alerts. Glowing confusion matrix. Brilliant metrics: "150K+ Items/Year", "12% Churn Reduction", "2.3x Feature Adoption", "80.6% Accuracy" in glowing ember orange (#D95B43). "When Machine-Generated Labels Outperform Human Annotation" in Inter font, white text. SaaS aesthetic with neon clarity showing AI intelligence trumping human labels.
```

---

### 4. Cloud Migration - 99.95% Uptime

#### Light Mode
**File:** `/assets/img/casestudies/cloud-migration-light.png`
**Aspect Ratio:** 3:2 landscape

```
Infrastructure transformation expressing production ML architecture over model complexity. White background. Split: LEFT - old monolithic server (single grey box) with red downtime alerts and Black Friday crash flames showing failure. RIGHT - modern cloud-native architecture: blue Kubernetes pods auto-scaling horizontally, load balancer in blue-grey distributing traffic, Redis cache in red (#DC382D), Istio service mesh in purple connecting microservices, CI/CD pipeline in green flowing. Traffic graph showing 10x spike handled smoothly. Bold metrics: "99.95% Uptime", "10x Traffic", "30% Cost Reduction", "Zero Downtime" in ember orange (#D95B43). Monitoring dashboards (Prometheus/Grafana) in success green. "Production ML is 10% Model, 90% Infrastructure" in Inter font, dark text. E-commerce reliability aesthetic celebrating infrastructure sophistication.
```

#### Dark Mode
**File:** `/assets/img/casestudies/cloud-migration-dark.png`
**Aspect Ratio:** 3:2 landscape

```
Infrastructure transformation with dramatic luminescence, expressing cloud-native mastery. Dark background (#1c1c1d). Split: LEFT - dim monolithic server with bright red alerts and Black Friday flames. RIGHT - glowing modern architecture: electric blue Kubernetes pods scaling with animation, glowing load balancer, bright Redis cache (#DC382D), glowing Istio mesh in purple, luminous CI/CD in green. Glowing traffic graph showing 10x spike handled. Brilliant metrics: "99.95% Uptime", "10x Traffic", "30% Cost Reduction", "Zero Downtime" in glowing ember orange (#D95B43). Glowing monitoring dashboards in bright green health. "Production ML is 10% Model, 90% Infrastructure" in Inter font, white text. E-commerce aesthetic with neon emphasis on infrastructure over models. Dense composition.
```

---

## ARCHITECTURE DIAGRAMS (3 × 2 = 6 images)

### 1. RAG System Architecture

#### Light Mode
**File:** `/assets/img/diagrams/rag-architecture-light.png`
**Aspect Ratio:** 3:2 landscape

```
Technical architecture diagram expressing RAG system design with precision and clarity. White background. Five-stage horizontal flow with structured arrows: (1) "Document Ingestion" - 10+ data source icons (email, SharePoint, CRM) in blue-grey feeding pipeline. (2) "Vector Embeddings" - documents chunking into 256-token segments with Cohere encoding visualization in purple. (3) "Vector Database" - Qdrant/ChromaDB storage cylinder with semantic index structure in blue. (4) "Semantic Search" - k=8 retrieval with query matching visualization in teal. (5) "Context-Aware Generation" - LLM (GPT-4/Claude) with dual personas (Engineering: technical depth, Marketing: business focus) generating responses in green. Technical annotations: "256-token chunks (Goldilocks zone)", "k=8 retrieval", "0.571 weighted score (ROUGE-L + Semantic + BLEU + BERTScore)". "RAG System Architecture" in Inter font, dark text. Ember accents (#D95B43) on optimal configuration choices. Clean technical diagram aesthetic emphasizing information architecture as success factor. Dense, structured composition.
```

#### Dark Mode
**File:** `/assets/img/diagrams/rag-architecture-dark.png`
**Aspect Ratio:** 3:2 landscape

```
Technical architecture diagram with glowing clarity, expressing RAG intelligence flow. Dark background (#1c1c1d). Five-stage luminous flow: (1) Glowing data sources feeding pipeline. (2) Glowing 256-token chunking with Cohere encoding in electric purple. (3) Luminous Qdrant database with bright semantic index in electric blue. (4) Glowing k=8 retrieval with query matching in neon teal. (5) Glowing LLM with dual persona badges (Engineering/Marketing) in bright green responses. Glowing annotations: "256-token chunks", "k=8 retrieval", "0.571 weighted score". "RAG System Architecture" in Inter font, white text. Bright ember highlights (#D95B43) on optimal configs. Glowing technical aesthetic emphasizing architectural precision. Dense structured composition with radiant flow.
```

---

### 2. Medical ML Architecture - Dual Path

#### Light Mode
**File:** `/assets/img/diagrams/medical-ml-architecture-light.png`
**Aspect Ratio:** 3:2 landscape

```
ML pipeline diagram expressing feature engineering triumph over deep learning. White background. Input: NIH Chest X-ray dataset "112,000+ images" flowing into dual parallel paths. TOP path (blue): "Deep Learning" - CNN architecture with layered visualization (convolutional → pooling → fully connected layers) training on 14 disease classes, producing 96+ AUC ROC curves for Cardiomegaly, Pleural Effusion, Pneumothorax in blue-green. BOTTOM path (green): "Traditional ML" - Feature Engineering extracting cardiac-thoracic ratio, lung symmetry, density distributions feeding Logistic Regression achieving "F1: 0.801" versus CNN "F1: 0.401" in comparison panel. Clinical validation showing interpretable coefficients for radiologist trust. Dual outputs: High-accuracy screening (DL blue) + Explainable diagnostics (Traditional green). "Dual-Architecture Medical Imaging System" in Inter font, dark text. Medical blue for X-rays, structured green for traditional ML, ember orange (#D95B43) on performance comparisons. Clinical precision aesthetic celebrating smart features. Dense technical layout.
```

#### Dark Mode
**File:** `/assets/img/diagrams/medical-ml-architecture-dark.png`
**Aspect Ratio:** 3:2 landscape

```
ML pipeline with luminous precision, expressing interpretable AI mastery. Dark background (#1c1c1d). Glowing NIH dataset "112,000+ images" flowing into dual glowing paths. TOP (electric blue): Glowing CNN with bright layered architecture producing brilliant 96+ AUC ROC curves for diseases. BOTTOM (bright green): Glowing Feature Engineering extracting measurements feeding glowing Logistic Regression achieving bright "F1: 0.801" versus dim CNN "F1: 0.401". Glowing clinical validation with interpretable coefficients. Dual glowing outputs: High-accuracy (bright blue DL) + Explainable (bright green ML). "Dual-Architecture Medical Imaging System" in Inter font, white text. Electric blue for X-rays, bright green for traditional ML, glowing ember orange (#D95B43) on performance wins. Clinical aesthetic with neon clarity celebrating features over complexity. Dense glowing composition.
```

---

### 3. Cloud-Native ML Deployment

#### Light Mode
**File:** `/assets/img/diagrams/cloud-deployment-architecture-light.png`
**Aspect Ratio:** 3:2 landscape

```
Production infrastructure diagram expressing cloud-native ML deployment sophistication. White background. Multi-layer architecture bottom-to-top: (1) "Container Layer" - Docker images with baked 1GB DistilBERT models in blue containers, callout "5min training vs 10hr production build". (2) "Orchestration" - Kubernetes cluster (official #326CE5 blue) with horizontal pod autoscaler responding to traffic load. (3) "Service Mesh" - Istio routing in purple with circuit breakers and monitoring. (4) "Caching" - Redis layer (official #DC382D red) with hash-based keys, callout "98% hit rate: 5ms vs 200ms". (5) "Load Balancing" - traffic distribution in teal. (6) "CI/CD" - GitHub Actions pipeline (test → build → deploy) in green. LEFT panel: k6 load testing showing "10x Black Friday traffic handled". RIGHT panel: Prometheus/Grafana dashboards showing "99.95% uptime", CPU scaling, "sub-100ms response" in green health. Critical callout in ember orange (#D95B43): "Model baked in Docker for <10s pod startup vs 60s runtime download". "Cloud-Native ML Production Architecture" in Inter font, dark text. Production-grade enterprise aesthetic emphasizing infrastructure over models. Dense multi-layer composition.
```

#### Dark Mode
**File:** `/assets/img/diagrams/cloud-deployment-architecture-dark.png`
**Aspect Ratio:** 3:2 landscape

```
Production infrastructure with electric sophistication, expressing cloud-native mastery. Dark background (#1c1c1d). Glowing multi-layer architecture: (1) Glowing Docker containers with DistilBERT, bright callout "5min training vs 10hr build". (2) Luminous Kubernetes (bright #326CE5) with glowing autoscaler. (3) Glowing Istio mesh in purple with circuit breakers. (4) Bright Redis (vivid #DC382D) with glowing "98% hit rate: 5ms vs 200ms" callout. (5) Glowing load balancer in neon teal. (6) Luminous CI/CD pipeline in bright green. LEFT: glowing k6 testing "10x traffic handled". RIGHT: glowing dashboards "99.95% uptime", glowing CPU scaling, bright "sub-100ms" in green. Critical glowing callout in brilliant ember orange (#D95B43): "Model baked for <10s startup". "Cloud-Native ML Production Architecture" in Inter font, white text. Glowing production aesthetic celebrating infrastructure sophistication. Dense glowing multi-layer composition.
```

---

## GENERATION SETTINGS

**For each image:**
1. Select **Imagen 4 Ultra** in model dropdown
2. Select **3:2 landscape** aspect ratio
3. Paste prompt
4. Generate
5. Download and rename according to file path specification

**After generation:**
- Images should generate at 1200×800px (3:2 ratio) directly
- Compress to 150-300KB for web performance
- Verify colors match specifications

**Total cost:** ~$2.16 (excellent ROI for professional portfolio)

---

## QUALITY CHECKLIST

After generating each image, verify:
- ✅ 3:2 aspect ratio (1200×800px)
- ✅ Background color matches theme (white or #1c1c1d)
- ✅ Ember orange (#D95B43) accents visible
- ✅ Title text readable
- ✅ Technology logos/elements present
- ✅ Dense composition, minimal empty space
- ✅ Professional, polished aesthetic

If quality insufficient, regenerate with same prompt (Imagen 4 Ultra gives variations).
